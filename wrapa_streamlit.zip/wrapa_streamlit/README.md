# WRAPA-ViT results explorer

    pip install -r requirements.txt
    streamlit run app.py

Pages: overview, WM-811K class distribution, geometry ablation, three-seed + adaptive gate,
rotation robustness, per-class/confusion matrix, learned gate weights, MixedWM38, and an interactive
phase explorer. CSV files hold training histories and per-class results; other numbers are in `app.py`.
